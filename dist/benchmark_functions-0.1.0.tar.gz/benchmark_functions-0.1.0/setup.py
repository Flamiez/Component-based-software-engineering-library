"""
Setup script for benchmark-functions package.
"""

from setuptools import setup

if __name__ == "__main__":
    setup() 